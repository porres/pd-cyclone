/* Copyright (c) 1997-2003 Miller Puckette, krzYszcz, and others.
 * For information on usage and redistribution, and for a DISCLAIMER OF ALL
 * WARRANTIES, see the file, "LICENSE.txt," in this distribution.  */

#ifndef __FRINGE_H__
#define __FRINGE_H__

void gobj_recreate(t_glist *gl, t_gobj *ob, t_binbuf *bb);

#endif
